from django.contrib import admin

# Register your models here.
from .models import Customer
class CustomerAdmin(admin.ModelAdmin):
    list_display = ['first_name','last_name','email','address','postal_code','city','age','user_customer']
    list_filter = ()
    search_fields = ['first_name','last_name']
    list_per_page = 5

admin.site.register(Customer,CustomerAdmin)