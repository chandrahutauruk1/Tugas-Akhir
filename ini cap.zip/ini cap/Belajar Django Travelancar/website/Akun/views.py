from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.shortcuts import render, render_to_response, redirect
from .models import Customer
from .formRegistration import RegistrationForm
from django.template import RequestContext

# Create your views here.
def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password1'],
                email=form.cleaned_data['email'],
            )

            user.save()
            current_user = user.id
            custom = Customer.objects.create(
                    first_name=form.cleaned_data['first_name'],
                    last_name=form.cleaned_data['last_name'],
                    # customer_user_id=user.id,
                    address =form.cleaned_data['address'],
                    postal_code=form.cleaned_data['postal_code'],
                    Origincountry=form.cleaned_data['Origin_country'],
                    city = form.cleaned_data['city'],
                    age=form.cleaned_data['age'],
                    # Gender=form.cleaned_data['Gender'],
                    user_customer_id=user.id
            )

            return render(request,'registration/sukses.html')
        # render = dilempar langsung
        # redirect = dilempar link
    else:
        form =RegistrationForm()
    variabels = RequestContext(request,{
    'form': form
    })

    return render_to_response('registration/register.html',variabels,)


def login_view(request):
    if request.POST:
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user is not None:
            if user.is_active:
                try:
                    user = User.objects.get(user=user.id)

                except:
                    messages.add_message(request, messages.INFO, 'Akun ini belum terhubung dengan data karyawan, silahkan hubungi administrator')

                    login(request, user)

                    request.session['username'] = user.username
                    request.session['email address'] = user.email
                    # q=user.values()
                    # #q = Akun.objetcs.get(akun_user_id=user.id).values()
                    #q = Akun.objects.values('akun_user_id').filter(akun_user_id=user.id)
                    return redirect('/hotel/')

                    # return render(request,'Hotel:hotel_list',{'q':q})
            else:
                messages.add_message(request, messages.INFO, 'User belum terverifikasi')
        else:
            messages.add_message(request, messages.INFO, 'Username atau password Anda salah')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('/login/')
from django.shortcuts import render

# Create your views here.
