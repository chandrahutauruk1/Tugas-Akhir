from django.contrib import admin

# Register your models here.
from .models import BookingHotel
# Register your models here.
class BookingHotelAdmin(admin.ModelAdmin):
    list_display = ['kamars','hotels','statusBooking']
    list_filter = ()
    search_fields = ['kamar']
    list_per_page = 5

admin.site.register(BookingHotel, BookingHotelAdmin)
