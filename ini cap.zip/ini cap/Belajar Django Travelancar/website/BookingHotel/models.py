from __future__ import unicode_literals
from hotel.models import Hotel,Kamar
#from Akun.models import Akun
from django.db import models

# Create your models here.
class BookingHotel(models.Model):
    hotels=models.ForeignKey(Hotel)
    kamars=models.ForeignKey(Kamar)
    statusBooking=models.CharField(max_length=20)
    #customer=models.ForeignKey(Akun)

    def __str__(self):
        return self.statusBooking
