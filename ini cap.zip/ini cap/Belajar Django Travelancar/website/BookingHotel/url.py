from django.conf.urls import url
from . import views


urlpatterns= [
    url(r'^bookinghotel/(?P<id_hotel>[0-9a-z-]+)/(?P<id_kamar>[0-9a-z-]+)$',views.bookinghotel,name='bookinghotel'),
]