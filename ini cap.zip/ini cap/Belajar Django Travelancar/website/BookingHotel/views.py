from django.http import Http404
from django.shortcuts import render
from .models import BookingHotel
from hotel.models import Hotel,Kamar

# Create your views here.
def bookinghotel(request,id_hotel,id_kamar):
    # if request.method=='POST':
    try:
        hotel=Hotel.objects.get(id=id_hotel)
        kamar=Kamar.objects.get(id=id_kamar)

        #current_user=request.id
        #akun =Akun.objects.get(akun_user_id=id_user)

        # print akun.id
        #hotels=Hotel.objects.get(id=id_hotel)
        # print hotels.id
        # kamars=Kamar.objects.get(id=id_kamar)
        # print kamars.id
        BookingHotel.objects.create(
            hotels_id=hotel.id,
            kamars_id=kamar.id,
            #customer_id=akun.id,
            statusBooking="booking"
        )
        # return render(request,'Booking_Hotel/list.html',{'bookinghotel':bookinghotels})
    except Hotel.DoesNotExist:
        raise Http404('Hotel tidak ada')
    return render(request, 'Booking_Hotel/list.html',)
    # else:
    #     return render(request, 'Booking_Hotel/gagal.html')
