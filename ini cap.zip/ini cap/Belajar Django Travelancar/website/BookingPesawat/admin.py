from django.contrib import admin
from .models import BookingPesawat
# Register your models here.
class BookingPesawatAdmin(admin.ModelAdmin):
    list_display = ['date_of_travel']
    list_filter = ()
    search_fields = ['date_of_travel']
    list_per_page = 10

admin.site.register(BookingPesawat,BookingPesawatAdmin)