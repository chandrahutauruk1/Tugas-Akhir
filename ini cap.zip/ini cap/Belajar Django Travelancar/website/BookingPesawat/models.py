from __future__ import unicode_literals

from django.db import models
from flight.models import FlightInstances

# Create your models here.
class BookingPesawat(models.Model):
    Flight_Instances_book = models.ForeignKey(FlightInstances,related_name="FlightInstanceIDBook",null=True)
    status_pesawat=models.CharField(max_length=20)
    date_of_travel=models.DateField()
    departure_time=models.TimeField()
    flight_legs=models.CharField(max_length=20,null=True)
    airplane=models.CharField(max_length=20,null=True)
    #arrive_time=models.TimeField()
    #flight_legs_book=models.ForeignKey(FlightInstances,related_name="Flight_legsIDBook")
    #airplane_book=models.ForeignKey(FlightInstances,related_name="AirplaneIDBook",null=True)

    def __str__(self):
        return self.status_pesawat



