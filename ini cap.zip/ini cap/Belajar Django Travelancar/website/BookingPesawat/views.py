from django.http import Http404
from django.shortcuts import render
from .models import BookingPesawat
from flight.models import FlightInstances,Route,Airplane,Flight_legs
# Create your views here.

def bookingpesawat(request,id,):
    try:
        flightInstances=FlightInstances.objects.get(id=id)
        flightLegs=Flight_legs.objects.get(id=flightInstances.id_flight_legs1.id)
        airplane=Airplane.objects.get(id=flightInstances.id_aiplane.id)

        BookingPesawat.objects.create(
            Flight_Instances_book_id=flightInstances.id,
            status_pesawat="booking",
            date_of_travel=flightInstances.date_of_travel,
            departure_time=flightInstances.departure_time,
            flight_legs=flightLegs.flight_no,
            airplane=airplane.airplane_name,
        )
    except FlightInstances.DoesNotExist:
        raise Http404('jadwal penerbangan tidak ada')
    return render(request,'Booking_Hotel/list.html', )





