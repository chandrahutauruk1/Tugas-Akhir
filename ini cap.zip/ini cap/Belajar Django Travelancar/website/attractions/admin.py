from django.contrib import admin
from .models import *


#Models Kota
class AdminAtraksi (admin.ModelAdmin):
    list_display = ['nama_atraksi']
    list_filter = ()
    search_fields = ['nama_atraksi']
    list_per_page = 10
admin.site.register(Atraksi, AdminAtraksi)