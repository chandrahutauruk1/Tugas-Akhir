from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Atraksi(models.Model):
    nama_atraksi = models.CharField(max_length=100)
    alamat_atraksi = models.CharField(max_length=100)
    keterangan_atraksi = models.CharField(max_length=100)
    opening_times = models.CharField(max_length=100)
    t_and_c = models.CharField(max_length=100)
    price_from = models.CharField(max_length=100)
    def __str__(self):
        return  self.nama_atraksi



