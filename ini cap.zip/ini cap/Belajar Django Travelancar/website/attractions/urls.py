from django.conf.urls import url
from . import views

app_name = 'attractions'

urlpatterns =[
    # /Attractions
    url(r'^$', views.index, name='index'),

# /attraksi/parameter/
    url(r'^(?P<attractions_id>[0-9]+)/$', views.detail, name='detail'),
]