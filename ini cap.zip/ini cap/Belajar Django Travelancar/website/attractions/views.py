from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
from .models import *
from django.http import Http404

def index(request):
    all_attractions = Atraksi.objects.all()
    context = {
        'all_attractions': all_attractions
    }
    return render(request, 'attractions/index.html', context)

def detail(request, attractions_id):
    try:
        attractions = Atraksi.objects.get(pk=attractions_id)
    except Atraksi.DoesNotExist:
        raise Http404("Atraksi does not exist")
    return render(request, 'attractions/detail.html',{'attractions': attractions})