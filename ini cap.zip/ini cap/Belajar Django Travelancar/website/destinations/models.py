from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Destinasi(models.Model):
    nama_destinasi = models.CharField(max_length=100)
    keterangan_destinasi = models.CharField(max_length=100)
    total_flight = models.IntegerField()
    total_hotel = models.IntegerField()
    total_attraction = models.IntegerField()
    price_from = models.CharField(max_length=100)
    def __str__(self):
        return  self.nama_destinasi

