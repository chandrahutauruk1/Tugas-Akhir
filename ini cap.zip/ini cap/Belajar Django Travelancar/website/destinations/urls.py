from django.conf.urls import url
from . import views

app_name = 'destinations'

urlpatterns =[
    # /Destinations
    url(r'^$', views.index, name='index'),

    # /Destinasi/parameter/
    url(r'^(?P<destinasi_id>[0-9]+)/$', views.detail, name='detail'),
]