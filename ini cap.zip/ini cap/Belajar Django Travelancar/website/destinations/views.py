from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
from .models import *
from django.http import Http404

def index(request):
    all_destinations = Destinasi.objects.all()
    context = {
        'all_destinations' : all_destinations
    }
    return render(request, 'destinations/index.html', context)

def detail(request, destinasi_id):
    try:
        destinasi = Destinasi.objects.get(pk=destinasi_id)
    except Destinasi.DoesNotExist:
        raise Http404("Destinasi does not exist")
    return render(request, 'destinations/detail.html',{'destinasi': destinasi})