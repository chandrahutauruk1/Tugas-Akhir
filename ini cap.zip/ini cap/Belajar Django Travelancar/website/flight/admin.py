from django.contrib import admin
from .models import *

#Models
class AdminCountry (admin.ModelAdmin):
    list_display = ['country_name']
    list_filter = ()
    search_fields = ['country_name']
    list_per_page = 10
admin.site.register(Country,AdminCountry)

class AdminLocation (admin.ModelAdmin):
    list_display = ['city']
    list_filter = ()
    search_fields = ['city']
    list_per_page = 10
admin.site.register(Location,AdminLocation)

class AdminAirport (admin.ModelAdmin):
    list_display = ['airport_name']
    list_filter = ()
    search_fields = ['airport_name']
    list_per_page = 10
admin.site.register(Airport,AdminAirport)

class AdminRoute (admin.ModelAdmin):
    list_display = ['route_origin', 'route_destination']
    list_filter = ()
    search_fields = ['route_origin', 'route_destination']
    list_per_page = 10
admin.site.register(Route,AdminRoute)

class AdminFlightLegs (admin.ModelAdmin):
    list_display = ['flight_no']
    list_filter = ()
    search_fields = ['flight_no']
    list_per_page = 10
admin.site.register(Flight_legs,AdminFlightLegs)

class AdminSeatClass (admin.ModelAdmin):
    list_display = ['class_name']
    list_filter = ()
    search_fields = ['class_name']
    list_per_page = 10
admin.site.register(SeatClass,AdminSeatClass)

class AdminAircraftType (admin.ModelAdmin):
    list_display = ['aircraft_type']
    list_filter = ()
    search_fields = ['aircraft_type']
    list_per_page = 10
admin.site.register(Aircraft_type,AdminAircraftType)

class AdminService (admin.ModelAdmin):
    list_display = ['service_name']
    list_filter = ()
    search_fields = ['service_name']
    list_per_page = 10
admin.site.register(Service,AdminService)

class AdminCompany(admin.ModelAdmin):
    list_display = ['company_name']
    list_filter = ()
    search_fields = ['company_name']
    list_per_page = 10
admin.site.register(Company, AdminCompany)

class AdminAirplane (admin.ModelAdmin):
    list_display = ['airplane_name']
    list_filter = ()
    search_fields = ['airplane_name']
    list_per_page = 10
admin.site.register(Airplane,AdminAirplane)

class AdminFlightInstances(admin.ModelAdmin):
    list_display = ['date_of_travel']
    list_filter = ()
    search_fields = ['date_of_travel']
    list_per_page = 10
admin.site.register(FlightInstances,AdminFlightInstances)







