from __future__ import unicode_literals

from django.db import models

class Country(models.Model):
    country_name = models.CharField(max_length=100)
    def __str__(self):
        return self.country_name

class Location(models.Model):
    city = models.CharField(max_length=100)
    state_name = models.CharField(max_length=100)
    id_country = models.ForeignKey(Country, null=True)
    def __str__(self):
        return self.city

class Airport(models.Model):
    airport_code = models.CharField(max_length=100)
    airport_name = models.CharField(max_length=100)
    place_address = models.CharField(max_length=100)
    id_location = models.ForeignKey(Location)
    def __str__(self):
        return self.airport_name

class Route(models.Model):
    route_origin = models.ForeignKey(Airport,related_name="route_origin_airport", null=True)
    route_destination = models.ForeignKey(Airport, related_name="route_destination_airport", null=True)
    route_description = models.CharField(max_length=100)
    distance_long = models.IntegerField()

    def __str__(self):
        return self.route_description

class Flight_legs(models.Model):
    flight_no = models.CharField(max_length=100)
    id_route = models.ForeignKey(Route)
    def __str__(self):
        return self.flight_no

class SeatClass(models.Model):
    class_name = models.CharField(max_length=100)
    seats = models.IntegerField()
    def __str__(self):
        return self.class_name

class Aircraft_type(models.Model):
    aircraft_type = models.CharField(max_length=100)
    id_class_seat = models.ForeignKey(SeatClass)
    def __str__(self):
        return self.aircraft_type

class Service(models.Model):
    service_name = models.CharField(max_length=100)
    service_description = models.CharField(max_length=100)
    def __str__(self):
        return self.service_name

class Company(models.Model):
    company_name = models.CharField(max_length=100)
    def __str__(self):
        return self.company_name

class Airplane(models.Model):
    airplane_name = models.CharField(max_length=100)
    id_aircraft_type = models.ForeignKey(Aircraft_type, null=True)
    id_service1 = models.ForeignKey(Service, related_name="service_1",null=True)
    id_service2 = models.ForeignKey(Service, related_name="service_2", null=True)
    id_service3 = models.ForeignKey(Service, related_name="service_3", null=True)
    id_service4 = models.ForeignKey(Service, related_name="service_4", null=True)
    id_company = models.ForeignKey(Company, null=True)
    def __str__(self):
        return self.airplane_name

class FlightInstances(models.Model):
    flight_instances_description = models.CharField(max_length=100, null=True)
    id_flight_legs1 = models.ForeignKey(Flight_legs, related_name="flight_leg_instances1", null=True)
    date_of_travel = models.DateField()
    departure_time = models.TimeField()
    arrive_time = models.TimeField()
    id_aiplane = models.ForeignKey(Airplane, related_name="flight_airplane", null=True)

    def __str__(self):
        return self.flight_instances_description