from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
from django.http import Http404
from models import *

def index(request):
    # query_form = request.GET.get("form")
    # query_to = request.GET.get("to")

    all_flights = FlightInstances.objects.all()
    #route = Route.objects.get(route_origin=query_form,route_destination=query_to)

    # if query_form:

    context = {
        'all_flights' : all_flights
    }
    return render(request, 'flight/index.html', context)

def detail(request, flight_id):
    try:
        flight = FlightInstances.objects.get(pk=flight_id)
    except FlightInstances.DoesNotExist:
        raise Http404("Flight does not exist")
    return render(request, 'flight/detail.html',{'flight': flight})