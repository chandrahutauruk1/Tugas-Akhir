from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.models import User
from django.http import HttpResponseRedirect
from django.shortcuts import render, render_to_response, redirect
from Akun.models import Customer

# Create your views here.
#Register
from django.template import RequestContext

from .formRegistration import RegistrationForm
# Create your views here.
def register(request):
    if request.method == 'POST':
        form = RegistrationForm(request.POST)
        if form.is_valid():
            user = User.objects.create_user(
                username=form.cleaned_data['username'],
                password=form.cleaned_data['password1'],
                email=form.cleaned_data['email'],
            )

            user.save()
            current_user = user.id
            akun = Akun.objects.create(
                  firstname=form.cleaned_data['firstname'],
                  lastname=form.cleaned_data['lastname'],
                  akun_user_id=user.id)
            # a = Akun.objects.filter(akun_user_id=current_user).values()
            # return render(request,'registration/sukses.html')
            return render(request,'registration/sukses.html')
        # render = dilempar langsung
        # redirect = dilempar link
    else:
        form =RegistrationForm()
    variabels = RequestContext(request,{
    'form': form
    })
    return render_to_response('registration/register.html',variabels,)


def login_view(request):
    if request.POST:
        user = authenticate(username=request.POST['username'], password=request.POST['password'])
        if user is not None:
            if user.is_active:
                try:
                    user = User.objects.get(user=user.id)

                except:
                    messages.add_message(request, messages.INFO, 'Akun ini belum terhubung dengan data karyawan, silahkan hubungi administrator')

                    login(request, user)

                    request.session['username'] = user.username
                    request.session['email address'] = user.email
                    # q=user.values()
                    # #q = Akun.objetcs.get(akun_user_id=user.id).values()
                    #q = Akun.objects.values('akun_user_id').filter(akun_user_id=user.id)
                    return redirect('/hotels/hotels/')

                    # return render(request,'Hotel:hotel_list',{'q':q})
            else:
                messages.add_message(request, messages.INFO, 'User belum terverifikasi')
        else:
            messages.add_message(request, messages.INFO, 'Username atau password Anda salah')
    return render(request, 'login.html')

def logout_view(request):
    logout(request)
    return redirect('/login/')
from django.shortcuts import render

# Create your views here.
