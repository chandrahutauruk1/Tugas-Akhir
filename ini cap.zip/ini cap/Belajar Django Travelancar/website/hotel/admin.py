from django.contrib import admin
from .models import *


#Models Kota
class AdminKota (admin.ModelAdmin):
    list_display = ['nama_kota','provinsi_kota']
    list_filter = ()
    search_fields = ['nama_kota', 'provinsi_kota']
    list_per_page = 10
admin.site.register(Kota,AdminKota)

#Models TipeKamar
class AdminTipeKamar (admin.ModelAdmin):
    list_display = ['nama_tipekamar','deskripsi_tipekamar']
    list_filter = ()
    search_fields = ['nama_tipekamar', 'deskripsi_tipekamar']
    list_per_page = 10
admin.site.register(TipeKamar, AdminTipeKamar)

#Models Kamar
class AdminKamar (admin.ModelAdmin):
    list_display = ['no_kamar','harga_kamar','id_tipekamar']
    list_filter = ()
    search_fields = ['no_kamar','harga_kamar','id_tipekamar']
    list_per_page = 10
admin.site.register(Kamar, AdminKamar)

#Models Kota
class AdminHotel (admin.ModelAdmin):
    list_display = ['kode_hotel','nama_hotel','alamat_hotel','gambarHotel']
    list_filter = ()
    search_fields = ['kode_hotel','nama_hotel','alamat_hotel']
    list_per_page = 10
admin.site.register(Hotel, AdminHotel)
