from __future__ import unicode_literals

from django.db import models

# Create your models here.
class Kota(models.Model):
    nama_kota = models.CharField(max_length=100)
    provinsi_kota = models.CharField(max_length=100)

    def __str__(self):
        return  self.nama_kota

class TipeKamar(models.Model):
    nama_tipekamar = models.CharField(max_length=100)
    deskripsi_tipekamar = models.CharField(max_length=100)
    gambar_tipekamar = models.CharField(max_length=100)

    def __str__(self):
        return  self.nama_tipekamar

class Hotel(models.Model):
    kode_hotel = models.CharField(max_length=100)
    nama_hotel = models.CharField(max_length=100)
    alamat_hotel = models.CharField(max_length=100)
    kodepos_hotel = models.CharField(max_length=100)
    url_hotel = models.CharField(max_length=100)
    #gambar_hotel = models.CharField(max_length=100)
    gambarHotel=models.ImageField(upload_to='hotelimage/%Y/%m/%d',blank=True)
    hotel_kota = models.ForeignKey(Kota,null=True)

    # hotel_kota=models.ForeignKey(Kota)

    def __str__(self):
        return self.nama_hotel

class Kamar(models.Model):
    harga_kamar = models.CharField(max_length=100)
    no_kamar = models.CharField(max_length=100)
    kapasitas = models.IntegerField()
    lantai_kamar = models.CharField(max_length=100)
    total_kamar = models.IntegerField()
    gambar_kamar = models.CharField(max_length=100)
    id_tipekamar = models.ForeignKey(TipeKamar)
    id_hotel = models.ForeignKey(Hotel)


    def __str__(self):
        return  self.harga_kamar

