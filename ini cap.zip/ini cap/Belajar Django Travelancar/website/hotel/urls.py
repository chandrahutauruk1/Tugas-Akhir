from django.conf.urls import url
from . import views

app_name = 'hotel'

urlpatterns =[
    # /Music/
    url(r'^$', views.index, name='index'),

    # /Music/parameter/
    url(r'^(?P<hotel_id>[0-9]+)/$', views.detail, name='detail'),
]