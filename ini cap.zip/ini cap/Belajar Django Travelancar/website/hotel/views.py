from django.http import HttpResponse
from django.template import loader
from django.shortcuts import render
from .models import *
from django.http import Http404

def index(request):
    all_hotels = Hotel.objects.all()

    query = request.GET.get("location")
    checkin1 = request.GET.get("Date1")
    checkout2 = request.GET.get("Date2")
    if query:
        kota = Kota.objects.get(nama_kota__icontains=query)
        all_hotels=all_hotels.filter(hotel_kota_id=kota.id)

    context = {
        'all_hotels' : all_hotels,
        'checkin1':checkin1,
        'checkout2':checkout2,
        'query':query,
    }

    return render(request, 'hotel/index.html', context)

def detail(request, hotel_id,):
    try:
        hotel = Hotel.objects.get(pk=hotel_id)
    except Hotel.DoesNotExist:
        raise Http404("Hotel does not exist")
    return render(request, 'hotel/detail.html',{'hotel': hotel})